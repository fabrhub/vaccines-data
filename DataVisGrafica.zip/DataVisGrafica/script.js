document.addEventListener("DOMContentLoaded", function(){
    //fetchInfoConsegneVacciniLatest(); //breve
    fetchInfoVacciniSummaryLatest(); //breve
    fetchInfoSomministrazioniVacciniLatest(); //lunghissimo
    //fetchInfoSomministrazioniVacciniSummaryLatest(); //medio
    //fetchInfoPuntiSomministrazioneLatest(); //breve
    //fetchInfoanAgraficaVacciniSummaryLatest(); //breve
    fetchInfoLastUpdateDataset(); //brevissimo
    //fetchInfoPuntiSomministrazioneTipologia(); //medio
});


function fetchInfoConsegneVacciniLatest() {
    var xhttp = new XMLHttpRequest();
    xhttp.onreadystatechange = function() {
        if (this.readyState == 4 && this.status == 404) {
            alert("Errore nel recupero dei dati");
        }
        if (this.readyState == 4 && this.status == 200) {
            jsonRicevuto = JSON.parse(this.responseText);
            var risp = this.responseText;
            document.getElementById("consegne-vaccini-latest").innerHTML = risp;
            console.log(risp);
            /*  document.getElementById("data").innerHTML = (jsonRicevuto[jsonRicevuto.length - 1].data).replace(/T/g, ' ').slice(0,16);
              document.getElementById("totale_attualmente_positivi").innerHTML = jsonRicevuto[jsonRicevuto.length - 1].totale_positivi;
              document.getElementById("dimessi_guariti").innerHTML = jsonRicevuto[jsonRicevuto.length - 1].dimessi_guariti;
              document.getElementById("ricoverati_con_sintomi").innerHTML = jsonRicevuto[jsonRicevuto.length - 1].ricoverati_con_sintomi;
              document.getElementById("terapia_intensiva").innerHTML = jsonRicevuto[jsonRicevuto.length - 1].terapia_intensiva;
              document.getElementById("totale_ospedalizzati").innerHTML = jsonRicevuto[jsonRicevuto.length - 1].totale_ospedalizzati;
              document.getElementById("isolamento_domiciliare").innerHTML = jsonRicevuto[jsonRicevuto.length - 1].isolamento_domiciliare;
              document.getElementById("nuovi_attualmente_positivi").innerHTML = jsonRicevuto[jsonRicevuto.length - 1].variazione_totale_positivi;
              document.getElementById("tamponi").innerHTML = jsonRicevuto[jsonRicevuto.length - 1].tamponi;
              document.getElementById("deceduti").innerHTML = jsonRicevuto[jsonRicevuto.length - 1].deceduti;
              document.getElementById("totale_casi").innerHTML = jsonRicevuto[jsonRicevuto.length - 1].totale_casi;
              document.getElementById("nuovi_positivi").innerHTML = jsonRicevuto[jsonRicevuto.length - 1].nuovi_positivi;*/

        }
    };
    xhttp.open("GET", "https://raw.githubusercontent.com/italia/covid19-opendata-vaccini/master/dati/consegne-vaccini-latest.json", true);
    xhttp.send();
};

function fetchInfoVacciniSummaryLatest() {
    var xhttp = new XMLHttpRequest();
    xhttp.onreadystatechange = function() {
        if (this.readyState == 4 && this.status == 404) {
            alert("Errore nel recupero dei dati");
        }
        let somministrazioni_totali = 0;
        if (this.readyState == 4 && this.status == 200) {
            var jsonRicevuto = JSON.parse(this.responseText);
            /*document.getElementById("vaccini-summary-latest").innerHTML = "ecco i dati: ";*/
            console.log(jsonRicevuto);
            console.log(jsonRicevuto.data.length);
            for (i = 0; i < jsonRicevuto.data.length; i++) {
                /*document.getElementById("vaccini-summary-latest_index").innerHTML += JSON.stringify(jsonRicevuto.data[i].index);
                document.getElementById("vaccini-summary-latest_area").innerHTML += JSON.stringify(jsonRicevuto.data[i].area);
                document.getElementById("vaccini-summary-latest_dosi_somministrate").innerHTML += JSON.stringify(jsonRicevuto.data[i].dosi_somministrate);
                document.getElementById("vaccini-summary-latest_dosi_consegnate").innerHTML += JSON.stringify(jsonRicevuto.data[i].dosi_consegnate);
                document.getElementById("vaccini-summary-latest_percentuale_somministrazione").innerHTML += JSON.stringify(jsonRicevuto.data[i].percentuale_somministrazione);
                document.getElementById("vaccini-summary-latest_ultimo_aggiornamento").innerHTML += JSON.stringify(jsonRicevuto.data[i].ultimo_aggiornamento);
                document.getElementById("vaccini-summary-latest_codice_NUTS1").innerHTML += JSON.stringify(jsonRicevuto.data[i].codice_NUTS1);
                document.getElementById("vaccini-summary-latest_codice_NUTS2").innerHTML += JSON.stringify(jsonRicevuto.data[i].codice_NUTS2);
                document.getElementById("vaccini-summary-latest_codice_regione_ISTAT").innerHTML += JSON.stringify(jsonRicevuto.data[i].codice_regione_ISTAT);
                document.getElementById("vaccini-summary-latest_nome_area").innerHTML += JSON.stringify(jsonRicevuto.data[i].nome_area);*/
                somministrazioni_totali += jsonRicevuto.data[i].dosi_somministrate;


                switch (jsonRicevuto.data[i].area) {
                    case "ABR":
                        document.getElementById("dc-abruzzo").innerHTML = jsonRicevuto.data[i].dosi_consegnate.toLocaleString();
                        document.getElementById("ds-abruzzo").innerHTML = jsonRicevuto.data[i].dosi_somministrate.toLocaleString();
                        document.getElementById("pc-abruzzo").innerHTML = jsonRicevuto.data[i].percentuale_somministrazione.toLocaleString() + "%";
                        break;
                    case "BAS":
                        document.getElementById("dc-basilicata").innerHTML = jsonRicevuto.data[i].dosi_consegnate.toLocaleString();
                        document.getElementById("ds-basilicata").innerHTML = jsonRicevuto.data[i].dosi_somministrate.toLocaleString();
                        document.getElementById("pc-basilicata").innerHTML = jsonRicevuto.data[i].percentuale_somministrazione.toLocaleString() + "%";
                        break;
                    case "CAL":
                        document.getElementById("dc-calabria").innerHTML = jsonRicevuto.data[i].dosi_consegnate.toLocaleString();
                        document.getElementById("ds-calabria").innerHTML = jsonRicevuto.data[i].dosi_somministrate.toLocaleString();
                        document.getElementById("pc-calabria").innerHTML = jsonRicevuto.data[i].percentuale_somministrazione.toLocaleString() + "%";
                        break;
                    case "CAM":
                        document.getElementById("dc-campania").innerHTML = jsonRicevuto.data[i].dosi_consegnate.toLocaleString();
                        document.getElementById("ds-campania").innerHTML = jsonRicevuto.data[i].dosi_somministrate.toLocaleString();
                        document.getElementById("pc-campania").innerHTML = jsonRicevuto.data[i].percentuale_somministrazione.toLocaleString() + "%";
                        break;
                    case "EMR":
                        document.getElementById("dc-emilia").innerHTML = jsonRicevuto.data[i].dosi_consegnate.toLocaleString();
                        document.getElementById("ds-emilia").innerHTML = jsonRicevuto.data[i].dosi_somministrate.toLocaleString();
                        document.getElementById("pc-emilia").innerHTML = jsonRicevuto.data[i].percentuale_somministrazione.toLocaleString() + "%";
                        break;
                    case "FVG":
                        document.getElementById("dc-fvg").innerHTML = jsonRicevuto.data[i].dosi_consegnate.toLocaleString();
                        document.getElementById("ds-fvg").innerHTML = jsonRicevuto.data[i].dosi_somministrate.toLocaleString();
                        document.getElementById("pc-fvg").innerHTML = jsonRicevuto.data[i].percentuale_somministrazione.toLocaleString() + "%";
                        break;
                    case "LAZ":
                        document.getElementById("dc-lazio").innerHTML = jsonRicevuto.data[i].dosi_consegnate.toLocaleString();
                        document.getElementById("ds-lazio").innerHTML = jsonRicevuto.data[i].dosi_somministrate.toLocaleString();
                        document.getElementById("pc-lazio").innerHTML = jsonRicevuto.data[i].percentuale_somministrazione.toLocaleString() + "%";
                        break;
                    case "LIG":
                        document.getElementById("dc-liguria").innerHTML = jsonRicevuto.data[i].dosi_consegnate.toLocaleString();
                        document.getElementById("ds-liguria").innerHTML = jsonRicevuto.data[i].dosi_somministrate.toLocaleString();
                        document.getElementById("pc-liguria").innerHTML = jsonRicevuto.data[i].percentuale_somministrazione.toLocaleString() + "%";
                        break;
                    case "LOM":
                        document.getElementById("dc-lombardia").innerHTML = jsonRicevuto.data[i].dosi_consegnate.toLocaleString();
                        document.getElementById("ds-lombardia").innerHTML = jsonRicevuto.data[i].dosi_somministrate.toLocaleString();
                        document.getElementById("pc-lombardia").innerHTML = jsonRicevuto.data[i].percentuale_somministrazione.toLocaleString() + "%";
                        break;
                    case "MAR":
                        document.getElementById("dc-marche").innerHTML = jsonRicevuto.data[i].dosi_consegnate.toLocaleString();
                        document.getElementById("ds-marche").innerHTML = jsonRicevuto.data[i].dosi_somministrate.toLocaleString();
                        document.getElementById("pc-marche").innerHTML = jsonRicevuto.data[i].percentuale_somministrazione.toLocaleString() + "%";
                        break;
                    case "MOL":
                        document.getElementById("dc-molise").innerHTML = jsonRicevuto.data[i].dosi_consegnate.toLocaleString();
                        document.getElementById("ds-molise").innerHTML = jsonRicevuto.data[i].dosi_somministrate.toLocaleString();
                        document.getElementById("pc-molise").innerHTML = jsonRicevuto.data[i].percentuale_somministrazione.toLocaleString() + "%";
                        break;
                    case "PAB":
                        document.getElementById("dc-bolzano").innerHTML = jsonRicevuto.data[i].dosi_consegnate.toLocaleString();
                        document.getElementById("ds-bolzano").innerHTML = jsonRicevuto.data[i].dosi_somministrate.toLocaleString();
                        document.getElementById("pc-bolzano").innerHTML = jsonRicevuto.data[i].percentuale_somministrazione.toLocaleString() + "%";
                        break;
                    case "PAT":
                        document.getElementById("dc-trento").innerHTML = jsonRicevuto.data[i].dosi_consegnate.toLocaleString();
                        document.getElementById("ds-trento").innerHTML = jsonRicevuto.data[i].dosi_somministrate.toLocaleString();
                        document.getElementById("pc-trento").innerHTML = jsonRicevuto.data[i].percentuale_somministrazione.toLocaleString() + "%";
                        break;
                    case "PIE":
                        document.getElementById("dc-piemonte").innerHTML = jsonRicevuto.data[i].dosi_consegnate.toLocaleString();
                        document.getElementById("ds-piemonte").innerHTML = jsonRicevuto.data[i].dosi_somministrate.toLocaleString();
                        document.getElementById("pc-piemonte").innerHTML = jsonRicevuto.data[i].percentuale_somministrazione.toLocaleString() + "%";
                        break;
                    case "PUG":
                        document.getElementById("dc-puglia").innerHTML = jsonRicevuto.data[i].dosi_consegnate.toLocaleString();
                        document.getElementById("ds-puglia").innerHTML = jsonRicevuto.data[i].dosi_somministrate.toLocaleString();
                        document.getElementById("pc-puglia").innerHTML = jsonRicevuto.data[i].percentuale_somministrazione.toLocaleString() + "%";
                        break;
                    case "SAR":
                        document.getElementById("dc-sardegna").innerHTML = jsonRicevuto.data[i].dosi_consegnate.toLocaleString();
                        document.getElementById("ds-sardegna").innerHTML = jsonRicevuto.data[i].dosi_somministrate.toLocaleString();
                        document.getElementById("pc-sardegna").innerHTML = jsonRicevuto.data[i].percentuale_somministrazione.toLocaleString() + "%";
                        break;
                    case "SIC":
                        document.getElementById("dc-sicilia").innerHTML = jsonRicevuto.data[i].dosi_consegnate.toLocaleString();
                        document.getElementById("ds-sicilia").innerHTML = jsonRicevuto.data[i].dosi_somministrate.toLocaleString();
                        document.getElementById("pc-sicilia").innerHTML = jsonRicevuto.data[i].percentuale_somministrazione.toLocaleString() + "%";
                        break;
                    case "TOS":
                        document.getElementById("dc-toscana").innerHTML = jsonRicevuto.data[i].dosi_consegnate.toLocaleString();
                        document.getElementById("ds-toscana").innerHTML = jsonRicevuto.data[i].dosi_somministrate.toLocaleString();
                        document.getElementById("pc-toscana").innerHTML = jsonRicevuto.data[i].percentuale_somministrazione.toLocaleString() + "%";
                        break;
                    case "UMB":
                        document.getElementById("dc-umbria").innerHTML = jsonRicevuto.data[i].dosi_consegnate.toLocaleString();
                        document.getElementById("ds-umbria").innerHTML = jsonRicevuto.data[i].dosi_somministrate.toLocaleString();
                        document.getElementById("pc-umbria").innerHTML = jsonRicevuto.data[i].percentuale_somministrazione.toLocaleString() + "%";
                        break;
                    case "VDA":
                        document.getElementById("dc-vda").innerHTML = jsonRicevuto.data[i].dosi_consegnate.toLocaleString();
                        document.getElementById("ds-vda").innerHTML = jsonRicevuto.data[i].dosi_somministrate.toLocaleString();
                        document.getElementById("pc-vda").innerHTML = jsonRicevuto.data[i].percentuale_somministrazione.toLocaleString() + "%";
                        break;
                    case "VEN":
                        document.getElementById("dc-veneto").innerHTML = jsonRicevuto.data[i].dosi_consegnate.toLocaleString();
                        document.getElementById("ds-veneto").innerHTML = jsonRicevuto.data[i].dosi_somministrate.toLocaleString();
                        document.getElementById("pc-veneto").innerHTML = jsonRicevuto.data[i].percentuale_somministrazione.toLocaleString() + "%";
                        break;
                    default:
                    // code block
                }
            }
            document.getElementById("tot-somministrazioni").innerHTML = somministrazioni_totali.toLocaleString();


        }
    };
    xhttp.open("GET", "https://raw.githubusercontent.com/italia/covid19-opendata-vaccini/master/dati/vaccini-summary-latest.json", true);
    xhttp.send();
};

function fetchInfoSomministrazioniVacciniLatest() {
    var xhttp = new XMLHttpRequest();
    xhttp.onreadystatechange = function() {
        if (this.readyState == 4 && this.status == 404) {
            alert("Errore nel recupero dei dati");
        }
        let dati_fornitori_pd = {};
        let dati_fornitori_sd = {};
        let tot_vaccinati = 0 ;
        if (this.readyState == 4 && this.status == 200) {
            jsonRicevuto = JSON.parse(this.responseText);
            //var risp = this.responseText;
            //console.log(risp);

            for (let i = 0; i < jsonRicevuto.data.length; i++) {

                dati_fornitori_pd[jsonRicevuto.data[i].fornitore] = (dati_fornitori_pd[jsonRicevuto.data[i].fornitore] || 0) + jsonRicevuto.data[i].prima_dose;
                dati_fornitori_sd[jsonRicevuto.data[i].fornitore] = (dati_fornitori_sd[jsonRicevuto.data[i].fornitore] || 0) + jsonRicevuto.data[i].seconda_dose;

                //Somma per vaccinati totali
                if( jsonRicevuto.data[i].fornitore == "Janssen"){
                    tot_vaccinati += jsonRicevuto.data[i].prima_dose
                } else {
                    tot_vaccinati += jsonRicevuto.data[i].seconda_dose
                }
                
            }
            document.getElementById("tot-persone").innerHTML = tot_vaccinati.toLocaleString("it");
            calcola_perc(tot_vaccinati);
            mostra_dosi_tabella(dati_fornitori_pd, dati_fornitori_sd)
            /* Mi servono: Dosi consegnate, dosi somministrate, 1° dose, 2° dose, somma 2° dose se != jensen */
        }

    };
    xhttp.open("GET", "https://raw.githubusercontent.com/italia/covid19-opendata-vaccini/master/dati/somministrazioni-vaccini-latest.json", true);
    xhttp.send();
};

function calcola_perc(totale_vaccinati){
    perc = (totale_vaccinati * 100) / 60000000;
    document.getElementById("now-color").style.width = perc + '%';
    document.getElementById("percentuale").innerHTML = perc.toFixed(1).replace('.',',') + '%' ;
}

function mostra_dosi_tabella(prima, seconda){
    for( var key in prima){
        switch (key){
            case 'Pfizer/BioNtech':
                document.getElementById("pd_pfz").innerHTML = prima[key].toLocaleString();
                document.getElementById("sd_pfz").innerHTML = seconda[key].toLocaleString();
                break;
            case 'Moderna':
                document.getElementById("pd_mod").innerHTML = prima[key].toLocaleString();
                document.getElementById("sd_mod").innerHTML = seconda[key].toLocaleString();
                break;
            case 'Vaxzevria (AstraZeneca)':
                document.getElementById("pd_vax").innerHTML = prima[key].toLocaleString();
                document.getElementById("sd_vax").innerHTML = seconda[key].toLocaleString();
                break;
            case 'Janssen':
                document.getElementById("pd_jan").innerHTML = prima[key].toLocaleString();
                document.getElementById("sd_jan").innerHTML = "Monodose";
                break;
            default:
                //Broken
        }
    }
}


function fetchInfoSomministrazioniVacciniSummaryLatest() {
    var xhttp = new XMLHttpRequest();
    xhttp.onreadystatechange = function() {
        if (this.readyState == 4 && this.status == 404) {
            alert("Errore nel recupero dei dati");
        }
        if (this.readyState == 4 && this.status == 200) {
            jsonRicevuto = JSON.parse(this.responseText);
            var risp = this.responseText;
            document.getElementById("somministrazioni-vaccini-summary-latest").innerHTML = risp;
            console.log(risp);
            /*  document.getElementById("data").innerHTML = (jsonRicevuto[jsonRicevuto.length - 1].data).replace(/T/g, ' ').slice(0,16);
              document.getElementById("totale_attualmente_positivi").innerHTML = jsonRicevuto[jsonRicevuto.length - 1].totale_positivi;
              document.getElementById("dimessi_guariti").innerHTML = jsonRicevuto[jsonRicevuto.length - 1].dimessi_guariti;
              document.getElementById("ricoverati_con_sintomi").innerHTML = jsonRicevuto[jsonRicevuto.length - 1].ricoverati_con_sintomi;
              document.getElementById("terapia_intensiva").innerHTML = jsonRicevuto[jsonRicevuto.length - 1].terapia_intensiva;
              document.getElementById("totale_ospedalizzati").innerHTML = jsonRicevuto[jsonRicevuto.length - 1].totale_ospedalizzati;
              document.getElementById("isolamento_domiciliare").innerHTML = jsonRicevuto[jsonRicevuto.length - 1].isolamento_domiciliare;
              document.getElementById("nuovi_attualmente_positivi").innerHTML = jsonRicevuto[jsonRicevuto.length - 1].variazione_totale_positivi;
              document.getElementById("tamponi").innerHTML = jsonRicevuto[jsonRicevuto.length - 1].tamponi;
              document.getElementById("deceduti").innerHTML = jsonRicevuto[jsonRicevuto.length - 1].deceduti;
              document.getElementById("totale_casi").innerHTML = jsonRicevuto[jsonRicevuto.length - 1].totale_casi;
              document.getElementById("nuovi_positivi").innerHTML = jsonRicevuto[jsonRicevuto.length - 1].nuovi_positivi;*/

        }
    };
    xhttp.open("GET", "https://raw.githubusercontent.com/italia/covid19-opendata-vaccini/master/dati/somministrazioni-vaccini-summary-latest.json", true);
    xhttp.send();
};

function fetchInfoPuntiSomministrazioneLatest() {
    var xhttp = new XMLHttpRequest();
    xhttp.onreadystatechange = function() {
        if (this.readyState == 4 && this.status == 404) {
            alert("Errore nel recupero dei dati");
        }
        if (this.readyState == 4 && this.status == 200) {
            jsonRicevuto = JSON.parse(this.responseText);
            var risp = this.responseText;
            document.getElementById("punti-somministrazione-latest").innerHTML = risp;
            console.log(risp);
            /*  document.getElementById("data").innerHTML = (jsonRicevuto[jsonRicevuto.length - 1].data).replace(/T/g, ' ').slice(0,16);
              document.getElementById("totale_attualmente_positivi").innerHTML = jsonRicevuto[jsonRicevuto.length - 1].totale_positivi;
              document.getElementById("dimessi_guariti").innerHTML = jsonRicevuto[jsonRicevuto.length - 1].dimessi_guariti;
              document.getElementById("ricoverati_con_sintomi").innerHTML = jsonRicevuto[jsonRicevuto.length - 1].ricoverati_con_sintomi;
              document.getElementById("terapia_intensiva").innerHTML = jsonRicevuto[jsonRicevuto.length - 1].terapia_intensiva;
              document.getElementById("totale_ospedalizzati").innerHTML = jsonRicevuto[jsonRicevuto.length - 1].totale_ospedalizzati;
              document.getElementById("isolamento_domiciliare").innerHTML = jsonRicevuto[jsonRicevuto.length - 1].isolamento_domiciliare;
              document.getElementById("nuovi_attualmente_positivi").innerHTML = jsonRicevuto[jsonRicevuto.length - 1].variazione_totale_positivi;
              document.getElementById("tamponi").innerHTML = jsonRicevuto[jsonRicevuto.length - 1].tamponi;
              document.getElementById("deceduti").innerHTML = jsonRicevuto[jsonRicevuto.length - 1].deceduti;
              document.getElementById("totale_casi").innerHTML = jsonRicevuto[jsonRicevuto.length - 1].totale_casi;
              document.getElementById("nuovi_positivi").innerHTML = jsonRicevuto[jsonRicevuto.length - 1].nuovi_positivi;*/

        }
    };
    xhttp.open("GET", "https://raw.githubusercontent.com/italia/covid19-opendata-vaccini/master/dati/punti-somministrazione-latest.json", true);
    xhttp.send();
};

function fetchInfoanAgraficaVacciniSummaryLatest() {
    var xhttp = new XMLHttpRequest();
    xhttp.onreadystatechange = function() {
        if (this.readyState == 4 && this.status == 404) {
            alert("Errore nel recupero dei dati");
        }
        if (this.readyState == 4 && this.status == 200) {
            jsonRicevuto = JSON.parse(this.responseText);
            var risp = this.responseText;
            document.getElementById("anagrafica-vaccini-summary-latest").innerHTML = risp;
            console.log(risp);
            /*  document.getElementById("data").innerHTML = (jsonRicevuto[jsonRicevuto.length - 1].data).replace(/T/g, ' ').slice(0,16);
              document.getElementById("totale_attualmente_positivi").innerHTML = jsonRicevuto[jsonRicevuto.length - 1].totale_positivi;
              document.getElementById("dimessi_guariti").innerHTML = jsonRicevuto[jsonRicevuto.length - 1].dimessi_guariti;
              document.getElementById("ricoverati_con_sintomi").innerHTML = jsonRicevuto[jsonRicevuto.length - 1].ricoverati_con_sintomi;
              document.getElementById("terapia_intensiva").innerHTML = jsonRicevuto[jsonRicevuto.length - 1].terapia_intensiva;
              document.getElementById("totale_ospedalizzati").innerHTML = jsonRicevuto[jsonRicevuto.length - 1].totale_ospedalizzati;
              document.getElementById("isolamento_domiciliare").innerHTML = jsonRicevuto[jsonRicevuto.length - 1].isolamento_domiciliare;
              document.getElementById("nuovi_attualmente_positivi").innerHTML = jsonRicevuto[jsonRicevuto.length - 1].variazione_totale_positivi;
              document.getElementById("tamponi").innerHTML = jsonRicevuto[jsonRicevuto.length - 1].tamponi;
              document.getElementById("deceduti").innerHTML = jsonRicevuto[jsonRicevuto.length - 1].deceduti;
              document.getElementById("totale_casi").innerHTML = jsonRicevuto[jsonRicevuto.length - 1].totale_casi;
              document.getElementById("nuovi_positivi").innerHTML = jsonRicevuto[jsonRicevuto.length - 1].nuovi_positivi;*/

        }
    };
    xhttp.open("GET", "https://raw.githubusercontent.com/italia/covid19-opendata-vaccini/master/dati/anagrafica-vaccini-summary-latest.json", true);
    xhttp.send();
};

function fetchInfoLastUpdateDataset() {
    var xhttp = new XMLHttpRequest();
    xhttp.onreadystatechange = function() {
        if (this.readyState == 4 && this.status == 404) {
            alert("Errore nel recupero dei dati");
        }
        if (this.readyState == 4 && this.status == 200) {
            jsonRicevuto = JSON.parse(this.responseText);
            console.log(jsonRicevuto);
            var millis = Date.parse(jsonRicevuto.ultimo_aggiornamento);
            var d = new Date(millis);
            document.getElementById("ora-aggiornamento").innerHTML = d.toLocaleDateString("it");
        }
    };
    xhttp.open("GET", "https://raw.githubusercontent.com/italia/covid19-opendata-vaccini/master/dati/last-update-dataset.json", true);
    xhttp.send();
};

function fetchInfoPuntiSomministrazioneTipologia() {
    var xhttp = new XMLHttpRequest();
    xhttp.onreadystatechange = function() {
        if (this.readyState == 4 && this.status == 404) {
            alert("Errore nel recupero dei dati");
        }
        if (this.readyState == 4 && this.status == 200) {
            jsonRicevuto = JSON.parse(this.responseText);
            var risp = this.responseText;
            document.getElementById("punti-somministrazione-tipologia").innerHTML = risp;
            console.log(risp);
            /*  document.getElementById("data").innerHTML = (jsonRicevuto[jsonRicevuto.length - 1].data).replace(/T/g, ' ').slice(0,16);
              document.getElementById("totale_attualmente_positivi").innerHTML = jsonRicevuto[jsonRicevuto.length - 1].totale_positivi;
              document.getElementById("dimessi_guariti").innerHTML = jsonRicevuto[jsonRicevuto.length - 1].dimessi_guariti;
              document.getElementById("ricoverati_con_sintomi").innerHTML = jsonRicevuto[jsonRicevuto.length - 1].ricoverati_con_sintomi;
              document.getElementById("terapia_intensiva").innerHTML = jsonRicevuto[jsonRicevuto.length - 1].terapia_intensiva;
              document.getElementById("totale_ospedalizzati").innerHTML = jsonRicevuto[jsonRicevuto.length - 1].totale_ospedalizzati;
              document.getElementById("isolamento_domiciliare").innerHTML = jsonRicevuto[jsonRicevuto.length - 1].isolamento_domiciliare;
              document.getElementById("nuovi_attualmente_positivi").innerHTML = jsonRicevuto[jsonRicevuto.length - 1].variazione_totale_positivi;
              document.getElementById("tamponi").innerHTML = jsonRicevuto[jsonRicevuto.length - 1].tamponi;
              document.getElementById("deceduti").innerHTML = jsonRicevuto[jsonRicevuto.length - 1].deceduti;
              document.getElementById("totale_casi").innerHTML = jsonRicevuto[jsonRicevuto.length - 1].totale_casi;
              document.getElementById("nuovi_positivi").innerHTML = jsonRicevuto[jsonRicevuto.length - 1].nuovi_positivi;*/

        }
    };
    xhttp.open("GET", "https://raw.githubusercontent.com/italia/covid19-opendata-vaccini/master/dati/punti-somministrazione-tipologia.json", true);
    xhttp.send();
};

function hoCliccatoSullaMappa(regione){
    console.log('Ho cliccato: ' + regione);

    switch(regione) {
        case "ABR":
            for (var item of document.querySelectorAll('tr')) {
                item.classList.remove('tr-selected');
            }
            document.getElementById("tr-abruzzo").classList.toggle("tr-selected");
            break;
        case "BAS":
            for (var item of document.querySelectorAll('tr')) {
                item.classList.remove('tr-selected');
            }
            document.getElementById("tr-basilicata").classList.toggle("tr-selected");
            break;
        case "CAL":
            for (var item of document.querySelectorAll('tr')) {
                item.classList.remove('tr-selected');
            }
            document.getElementById("tr-calabria").classList.toggle("tr-selected");
            break;
        case "CAM":
            for (var item of document.querySelectorAll('tr')) {
                item.classList.remove('tr-selected');
            }
            document.getElementById("tr-campania").classList.toggle("tr-selected");
            break;
        case "EMR":
            for (var item of document.querySelectorAll('tr')) {
                item.classList.remove('tr-selected');
            }
            document.getElementById("tr-emilia").classList.toggle("tr-selected");
            break;
        case "FVG":
            for (var item of document.querySelectorAll('tr')) {
                item.classList.remove('tr-selected');
            }
            document.getElementById("tr-fvg").classList.toggle("tr-selected");
            break;
        case "LAZ":
            for (var item of document.querySelectorAll('tr')) {
                item.classList.remove('tr-selected');
            }
            document.getElementById("tr-lazio").classList.toggle("tr-selected");
            break;
        case "LIG":
            for (var item of document.querySelectorAll('tr')) {
                item.classList.remove('tr-selected');
            }
            document.getElementById("tr-liguria").classList.toggle("tr-selected");
            break;
        case "LOM":
            for (var item of document.querySelectorAll('tr')) {
                item.classList.remove('tr-selected');
            }
            document.getElementById("tr-lombardia").classList.toggle("tr-selected");
            break;
        case "MAR":
            for (var item of document.querySelectorAll('tr')) {
                item.classList.remove('tr-selected');
            }
            document.getElementById("tr-marche").classList.toggle("tr-selected");
            break;
        case "MOL":
            for (var item of document.querySelectorAll('tr')) {
                item.classList.remove('tr-selected');
            }
            document.getElementById("tr-molise").classList.toggle("tr-selected");
            break;
        case "TRN":
            for (var item of document.querySelectorAll('tr')) {
                item.classList.remove('tr-selected');
            }
            document.getElementById("tr-trento").classList.toggle("tr-selected");
            document.getElementById("tr-bolzano").classList.toggle("tr-selected");
            break;
        case "PIE":
            for (var item of document.querySelectorAll('tr')) {
                item.classList.remove('tr-selected');
            }
            document.getElementById("tr-piemonte").classList.toggle("tr-selected");
            break;
        case "PUG":
            for (var item of document.querySelectorAll('tr')) {
                item.classList.remove('tr-selected');
            }
            document.getElementById("tr-puglia").classList.toggle("tr-selected");
            break;
        case "SAR":
            for (var item of document.querySelectorAll('tr')) {
                item.classList.remove('tr-selected');
            }
            document.getElementById("tr-sardegna").classList.toggle("tr-selected");
            break;
        case "SIC":
            for (var item of document.querySelectorAll('tr')) {
                item.classList.remove('tr-selected');
            }
            document.getElementById("tr-sicilia").classList.toggle("tr-selected");
            break;
        case "TOS":
            for (var item of document.querySelectorAll('tr')) {
                item.classList.remove('tr-selected');
            }
            document.getElementById("tr-toscana").classList.toggle("tr-selected");
            break;
        case "UMB":
            for (var item of document.querySelectorAll('tr')) {
                item.classList.remove('tr-selected');
            }
            document.getElementById("tr-umbria").classList.toggle("tr-selected");
            break;
        case "VDA":
            for (var item of document.querySelectorAll('tr')) {
                item.classList.remove('tr-selected');
            }
            document.getElementById("tr-vda").classList.toggle("tr-selected");
            break;
        case "VEN":
            for (var item of document.querySelectorAll('tr')) {
                item.classList.remove('tr-selected');
            }
            document.getElementById("tr-veneto").classList.toggle("tr-selected");
            break;
        default:
            for (var item of document.querySelectorAll('tr')) {
                item.classList.remove('tr-selected');
            }
    }
    
    



}